# https://swapi.co/documentation
class StarWars

end
